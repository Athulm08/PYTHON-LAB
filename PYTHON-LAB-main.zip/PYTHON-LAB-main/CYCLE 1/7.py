                                                  
n = int(input("Entet the number"))
print(f"{n} + {n}{n} + {n}{n}{n}")
sum = n + (n*10 + n) + (n*100+n*10+n)
print(f"Sum : ", sum)









