
r = float(input("Enter the radius : "))
area = 3.14 * r * r
print("Area : ",area)









