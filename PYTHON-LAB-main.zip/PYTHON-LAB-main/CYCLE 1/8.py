a = int(input("Enter first number : "))
b = int(input("Enter the second number : "))
c = int(input("Enter the third number : "))
if(a > b and a > c):
        print("Biggest number : ", a)
elif(b > a and b > c):
        print("Biggest number : ", b)
else:
        print("Biggest number : ", c)

