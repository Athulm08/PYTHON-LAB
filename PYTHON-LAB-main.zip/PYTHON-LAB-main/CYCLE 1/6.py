a = int(input("Enter the first number : "))
b = int(input("Enter the second number : "))
print("Sum : ", a + b)
print("Difference : ", a - b)
print("Multiplication : ", a * b)
if(b == 0):
        print("Division - Cant divide by zero ")
else:
        print("Division : ", a / b)
if(b == 0):
        print("Modulus - Cant divide by zero ")
else:
        print("Remainder : ", a % b)