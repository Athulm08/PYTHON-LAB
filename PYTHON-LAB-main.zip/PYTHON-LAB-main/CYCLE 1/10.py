age = int(input("Enter the age : "))
if(age >= 60):
        print("Ticket Rate : 5 ")
elif(age < 60 and age >= 10 ):
        print("Ticket Rate : 10 ")
else:
        print("Ticket Rate : 7 ")












