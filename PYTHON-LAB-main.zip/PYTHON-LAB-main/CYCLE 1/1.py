fname = input("Enter your first name : ")
lname = input("Enter your last name : ")
print("Greetings !!! ",fname,lname)