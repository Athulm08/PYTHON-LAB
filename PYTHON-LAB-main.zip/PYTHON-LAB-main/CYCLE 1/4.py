bPay = int(input("Enter the basic pay of the employee : "))
HRA = 0.10 * bPay
TA = 0.05 * bPay
salary = bPay + HRA + TA
print("Salary : ",salary)
