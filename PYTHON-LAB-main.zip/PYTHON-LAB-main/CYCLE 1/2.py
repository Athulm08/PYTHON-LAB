                                                          
a = 23
b = 23.54
c = "Python"
d = 5 + 6j
print("Type of a : ",type(a))
print("Type of b : ",type(b))
print("Type of c : ",type(c))
print("Type of d : ",type(d))






