name = input("Enter your name : ")
print(f"Original string : {name}")
print(f"New string : {name*5}")






